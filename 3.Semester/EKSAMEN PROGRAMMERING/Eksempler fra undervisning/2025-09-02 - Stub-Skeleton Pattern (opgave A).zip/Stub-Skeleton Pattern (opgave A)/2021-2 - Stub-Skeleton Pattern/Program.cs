﻿using System;

namespace StubSkeletonPattern {

  public class Program {

    public static void Main() {
      Person p1 = new Person("Jens Jensen", 30);

      string xml = p1.ToXml();

      Console.WriteLine(xml);

      // Man skal allerede vide, at det er en Person.
      Person p2 = new Person();

      p2.FromXml(xml);

      Console.WriteLine(p2);
    }
  }
}
