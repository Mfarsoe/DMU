﻿// See https://aka.ms/new-console-template for more information

using Multi_Threaded_Server.Client;
using Multi_Threaded_Server.Server;

ClientManager manager = new ClientManager(6010);
manager.Start();

Thread.Sleep(100); // være sikker på at serveren er online

SimpleClient client = new SimpleClient();
client.Start();

Thread.Sleep(2000);
manager.Shutdown();