﻿
namespace Multi_Threaded_Server.Common {

  abstract class AbstractThread {

    public void Start() {
      new Thread(Run).Start();
    }

    public abstract void Run();
  }
}
