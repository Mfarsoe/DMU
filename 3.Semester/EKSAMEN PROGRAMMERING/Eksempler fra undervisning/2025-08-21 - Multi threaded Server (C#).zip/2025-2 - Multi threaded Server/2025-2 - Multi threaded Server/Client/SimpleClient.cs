﻿using Multi_Threaded_Server.Common;
using System.Net;
using System.Net.Sockets;

namespace Multi_Threaded_Server.Client {

  class SimpleClient : AbstractThread {

    public override void Run() {
      try {
        Socket connection = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        connection.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 6010));

        Console.WriteLine("[Client] Connection open");

        NetworkStream stream = new NetworkStream(connection);
        StreamWriter writer = new StreamWriter(stream);
        StreamReader reader = new StreamReader(stream);

        SendLine(writer, "LOGIN viggo");
        SendLine(writer, "MESSAGE niels Hej, hvordan går det?");
        // LOGOUT udkommenteret, så vi ikke skal til at lave en ny forbindelse til serveren
        //SendLine(writer, "LOGOUT");

        SendLine(writer, "LOGIN niels");
        SendLine(writer, "GET");
        Console.WriteLine("[Client] " + reader.ReadLine());
        SendLine(writer, "GET");
        Console.WriteLine("[Client] " + reader.ReadLine());
        SendLine(writer, "LOGOUT");

        writer.Close();
        reader.Close();
        connection.Close();

        Console.WriteLine("[Client] Connection closed");
      }
      catch (IOException) {
        Console.WriteLine("[Client] Connection failed");
      }
    }

    private void SendLine(StreamWriter writer, String line) {
      Console.WriteLine("[SimpleClient] sending line: " + line);

      writer.WriteLine(line);
      writer.Flush();

      Thread.Sleep(100);
    }
  }
}
