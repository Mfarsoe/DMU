﻿using Multi_Threaded_Server.Common;
using System.Net;
using System.Net.Sockets;

namespace Multi_Threaded_Server.Server {

  class ClientWorker : AbstractThread {
    private Socket connection;
    private ClientManager manager;
    private String? userName;

    public ClientWorker(ClientManager manager, Socket connection) {
      this.manager = manager;
      this.connection = connection;

      userName = null;
    }

    public override void Run() {
      Console.WriteLine("[ClientWorker] New connection from: " +
                          ((IPEndPoint?) connection?.RemoteEndPoint)?.Address);

      try {
        NetworkStream stream = new NetworkStream(connection);
        StreamWriter writer = new StreamWriter(stream);
        StreamReader reader = new StreamReader(stream);

        while (true) {
          String? line = reader.ReadLine();

          if (line == null) // lost connection!
            break;

          String[] tokens = line.Split(" ");
          // eller: String[] tokens = line.split( " ", 3 )
          //        og dernæst bruge tokens[2] for beskeden

          String command = tokens[0].ToUpper();

          Console.WriteLine("[ClientWorker] Received command: " + command);

          if (command.Equals("LOGIN")) {
            userName = tokens[1];

          } else if (command.Equals("MESSAGE")) {
            String to = tokens[1];
            String message = Tail(Tail(line));

            manager.StoreMessage(to, message);

          } else if (command.Equals("GET")) {
            String message = manager.GetMessage(userName);

            if (message != null)
              SendLine(writer, message);
            else
              SendLine(writer, "no messages");

          } else if (command.Equals("LOGOUT"))
            break;
        }

        reader.Close();
        writer.Close();

        Console.WriteLine("[ClientWorker] Connection closed");
      }
      catch (IOException) {
        Console.WriteLine("[ClientWorker] I/O error");
      }
    }

    private String Tail(String text) {
      int pos = text.IndexOf(' ');

      if (pos >= 0)
        return text.Substring(pos + 1).Trim();
      else
        return "";
    }

    private void SendLine(StreamWriter writer, String line) {
      Console.WriteLine($"[ClientWorker] sending line: {line}");

      writer.WriteLine(line);
      writer.Flush();

      Thread.Sleep(100);
    }
  }
}

