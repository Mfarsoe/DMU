﻿using Multi_Threaded_Server.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Threaded_Server.Server {

  class ClientManager : AbstractThread {
    private readonly List<ClientWorker> workers;
    private readonly int port;
    private bool stop;

    public ClientManager(int port) {
      this.port = port;
      this.stop = false;

      workers = new List<ClientWorker>();
      messages = new List<Message>();
    }

    public override void Run() {
      try {
        TcpListener server = new TcpListener(IPAddress.Any, port);
        server.Start();
        Console.WriteLine("[ClientManager] Server online");

        while (!stop)
          try {
            if (server.Pending()) {
              Socket connection = server.AcceptSocket();

              ClientWorker worker = new ClientWorker(this, connection);
              workers.Add(worker);
              worker.Start();

            } else
              Thread.Sleep(100);
          }
          catch {
            // ignore
          }

        Console.WriteLine("[ClientManager] Server offline");
      }
      catch (IOException) {
        Console.WriteLine("[ClientManager] I/O error");
      }
    }

    public void Shutdown() {
      stop = true;
    }

    /*
     * Messages
     */
    private readonly List<Message> messages;

    public void StoreMessage(String to, String message) {
      messages.Add(new Message(to, message));
    }

    public String? GetMessage(String userName) {
      foreach (Message message in messages)
        if (message.IsTo(userName)) {
          messages.Remove(message);
          return message.GetMessage();
        }

      return null;
    }
  }
}
