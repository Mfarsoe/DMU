﻿
namespace Multi_Threaded_Server.Server {

  class Message {
    private readonly string to;
    private readonly string message;

    public Message(string to, string message) {
      this.to = to;
      this.message = message;
    }

    public bool IsTo(string userName) {
      return to.Equals(userName, StringComparison.InvariantCultureIgnoreCase);
    }

    public string GetMessage() {
      return message;
    }
  }
}
