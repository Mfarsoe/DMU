﻿using StubSkeletonPattern;

public interface IMethodImpl {
  Person Oldest(Person p1, Person p2);
}
