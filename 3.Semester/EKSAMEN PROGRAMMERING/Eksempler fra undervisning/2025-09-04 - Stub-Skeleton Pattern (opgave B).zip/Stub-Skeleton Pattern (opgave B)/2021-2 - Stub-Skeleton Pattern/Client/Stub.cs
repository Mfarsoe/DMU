﻿using StubSkeletonPattern.Common;
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace StubSkeletonPattern.Client {

  internal class Stub {
    private readonly string host;
    private readonly int port;

    private StreamReader reader; // no used (yet)
    private StreamWriter writer;

    public Stub(string host, int port) {
      this.host = host;
      this.port = port;
    }

    internal void Send(Person person) {
      try {
        using (Socket connection = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)) {
          connection.Connect(new IPEndPoint(IPAddress.Parse(host), port));

          using (NetworkStream stream = new NetworkStream(connection))
          using (reader = new StreamReader(stream))
          using (writer = new StreamWriter(stream)) {
            string xml = person.ToXml();

            WriteLine(xml);

            SendLine(xml);
          }
        }

        WriteLine("Terminated");
      }
      catch {
        WriteLine("Could not connect to server");
      }
    }

    private void SendLine(string line) {
      WriteLine("Sending line: " + line);

      writer.WriteLine(line);
      writer.Flush();

      Thread.Sleep(100); // nap, afht. simuleringen
    }

    private void WriteLine(object line) {
      ConsoleUtils.WriteLine(ConsoleColor.DarkGray, "[Stub] " + line);
    }
  }
}
