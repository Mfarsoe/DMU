﻿
namespace StubSkeletonPattern.Common {

  public interface IShutdownable {
    void Shutdown(bool waitForTermination);
  }
}
